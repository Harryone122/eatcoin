import pygame
import random
import sys

pygame.init()

screen_width = 800
screen_height = 600
screen = pygame.display.set_mode((screen_width, screen_height))

white = (255, 255, 255)
blue = (0, 0, 255)
yellow = (255, 255, 0)

player_image = pygame.image.load('character.png')
player_size = 50
player_speed = 10

coin_image = pygame.image.load('coin.png')
coin_size = 30
coin_speed = 5

window = pygame.display.set_mode((screen_width, screen_height))
pygame.display.set_caption("吃金幣")

player_x = screen_width // 2
player_y = screen_height // 2
score = 0

font = pygame.font.Font(None, 36)

def generate_coin():
    coin_x = random.randint(0, screen_width - coin_size)
    coin_y = random.randint(0, screen_height - coin_size)
    return coin_x, coin_y

def draw_player(x, y):
    screen.blit(player_image, (x, y))

def draw_coin(x, y):
    screen.blit(coin_image, (x, y))

def display_score(score):
    score_text = font.render("Score: " + str(score), True, white)
    window.blit(score_text, (10, 10))

def collision_detection(player_x, player_y, coin_x, coin_y):
    if player_x < coin_x + coin_size and player_x + player_size > coin_x and \
       player_y < coin_y + coin_size and player_y + player_size > coin_y:
        return True
    return False

def start_screen():
    start = False
    font_size = 60
    growing = True  
    delta = 1  

    while not start:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            if event.type == pygame.KEYDOWN:
                start = True

        screen.fill((0, 0, 0))

        if growing:
            font_size += delta
            if font_size > 70:  
                growing = False
        else:
            font_size -= delta
            if font_size < 50:  
                growing = True

        title_font = pygame.font.Font(None, font_size)
        instruction_font = pygame.font.Font(None, int(font_size * 0.85))  

        title_text = "Use WASD to play"
        instruction_text = "Press any key to start the game"

        title_surface = title_font.render(title_text, True, white)
        instruction_surface = instruction_font.render(instruction_text, True, white)

        title_rect = title_surface.get_rect(center=(screen_width / 2, screen_height / 2 - 30))
        instruction_rect = instruction_surface.get_rect(center=(screen_width / 2, screen_height / 2 + 20))

        screen.blit(title_surface, title_rect)
        screen.blit(instruction_surface, instruction_rect)

        pygame.display.flip()  

        pygame.time.delay(100)  

start_screen()


coin_x, coin_y = generate_coin()

running = True
clock = pygame.time.Clock()


start_screen()

while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

    keys = pygame.key.get_pressed()
    if keys[pygame.K_a]:
        player_x -= player_speed
    if keys[pygame.K_d]:
        player_x += player_speed
    if keys[pygame.K_w]:
        player_y -= player_speed
    if keys[pygame.K_s]:
        player_y += player_speed

    if collision_detection(player_x, player_y, coin_x, coin_y):
        coin_x, coin_y = generate_coin()
        score += 1

    window.fill((0, 0, 0))
    draw_player(player_x, player_y)
    draw_coin(coin_x, coin_y)
    display_score(score)

    pygame.display.update()
    clock.tick(30)

pygame.quit()
